package com.ipad.project.population.model;

import org.springframework.stereotype.Component;

@Component
public class RegionDataUpdateVO {

	private String adm_cd;

	private int houseHold;
	private int dentalClinic;
	private int income;
	private int resident;

	private int floatingPp;

	private int housePrice;
	private int subway;
	private int bus;
	public String getAdm_cd() {
		return adm_cd;
	}
	public void setAdm_cd(String adm_cd) {
		this.adm_cd = adm_cd;
	}
	public int getHouseHold() {
		return houseHold;
	}
	public void setHouseHold(int houseHold) {
		this.houseHold = houseHold;
	}
	public int getDentalClinic() {
		return dentalClinic;
	}
	public void setDentalClinic(int dentalClinic) {
		this.dentalClinic = dentalClinic;
	}
	public int getIncome() {
		return income;
	}
	public void setIncome(int income) {
		this.income = income;
	}
	public int getResident() {
		return resident;
	}
	public void setResident(int resident) {
		this.resident = resident;
	}
	public int getFloatingPp() {
		return floatingPp;
	}
	public void setFloatingPp(int floatingPp) {
		this.floatingPp = floatingPp;
	}
	public int getHousePrice() {
		return housePrice;
	}
	public void setHousePrice(int housePrice) {
		this.housePrice = housePrice;
	}
	public int getSubway() {
		return subway;
	}
	public void setSubway(int subway) {
		this.subway = subway;
	}
	public int getBus() {
		return bus;
	}
	public void setBus(int bus) {
		this.bus = bus;
	}
	
	
}
