package com.ipad.project.saleAnalysis.service;

import java.util.List;

import com.ipad.project.saleAnalysis.model.SaleOverlayVO;

public interface ISaleOverlayService {
	List<SaleOverlayVO> getOverlay();
}
