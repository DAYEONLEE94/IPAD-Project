package com.ipad.project.saleAnalysis.model;

public class PatientPointVO {
	private int constant;
	private int population_point;
	private int float_point;
	private int income_point;
	private int dentist_point;
	
	public int getConstant() {
		return constant;
	}
	public void setConstant(int constant) {
		this.constant = constant;
	}
	public int getPopulation_point() {
		return population_point;
	}
	public void setPopulation_point(int population_point) {
		this.population_point = population_point;
	}
	public int getFloat_point() {
		return float_point;
	}
	public void setFloat_point(int float_point) {
		this.float_point = float_point;
	}
	public int getIncome_point() {
		return income_point;
	}
	public void setIncome_point(int income_point) {
		this.income_point = income_point;
	}
	public int getDentist_point() {
		return dentist_point;
	}
	public void setDentist_point(int dentist_point) {
		this.dentist_point = dentist_point;
	}
	
	
}
