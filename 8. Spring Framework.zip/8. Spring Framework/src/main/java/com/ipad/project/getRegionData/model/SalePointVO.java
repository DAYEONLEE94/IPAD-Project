package com.ipad.project.getRegionData.model;

public class SalePointVO {
	int constant;
	
	int twentiesPoint;
	int thirtiesPoint;
	int sixtiesPoint;
	int over70sPoint;
	int floatPoint;
	int incomePoint;
	int dentalClinicPoint;
	int subwayPoint;
	public int getConstant() {
		return constant;
	}
	public void setConstant(int constant) {
		this.constant = constant;
	}
	
	public int getTwentiesPoint() {
		return twentiesPoint;
	}
	public void setTwentiesPoint(int twentiesPoint) {
		this.twentiesPoint = twentiesPoint;
	}
	public int getThirtiesPoint() {
		return thirtiesPoint;
	}
	public void setThirtiesPoint(int thirtiesPoint) {
		this.thirtiesPoint = thirtiesPoint;
	}
	public int getSixtiesPoint() {
		return sixtiesPoint;
	}
	public void setSixtiesPoint(int sixtiesPoint) {
		this.sixtiesPoint = sixtiesPoint;
	}
	public int getOver70sPoint() {
		return over70sPoint;
	}
	public void setOver70sPoint(int over70sPoint) {
		this.over70sPoint = over70sPoint;
	}
	public int getFloatPoint() {
		return floatPoint;
	}
	public void setFloatPoint(int floatPoint) {
		this.floatPoint = floatPoint;
	}
	public int getIncomePoint() {
		return incomePoint;
	}
	public void setIncomePoint(int incomePoint) {
		this.incomePoint = incomePoint;
	}
	public int getDentalClinicPoint() {
		return dentalClinicPoint;
	}
	public void setDentalClinicPoint(int dentalClinicPoint) {
		this.dentalClinicPoint = dentalClinicPoint;
	}
	public int getSubwayPoint() {
		return subwayPoint;
	}
	public void setSubwayPoint(int subwayPoint) {
		this.subwayPoint = subwayPoint;
	}
	
}
