package com.ipad.dto.saleAnalysis;

public class CalSaleDto {
	private int sale;
	
	private String adm_cd;
	private int twenties;
	private int thirties;
	private int sixties;
	private int over70s;
	private int floatPp;
	private int income;
	private int dentalClinic;
	private int subway;
	
	public int getSale() {
		return sale;
	}
	public void setSale(int sale) {
		this.sale = sale;
	}
	public String getAdm_cd() {
		return adm_cd;
	}
	public void setAdm_cd(String adm_cd) {
		this.adm_cd = adm_cd;
	}
	public int getTwenties() {
		return twenties;
	}
	public void setTwenties(int twenties) {
		this.twenties = twenties;
	}
	public int getThirties() {
		return thirties;
	}
	public void setThirties(int thirties) {
		this.thirties = thirties;
	}
	public int getSixties() {
		return sixties;
	}
	public void setSixties(int sixties) {
		this.sixties = sixties;
	}
	public int getOver70s() {
		return over70s;
	}
	public void setOver70s(int over70s) {
		this.over70s = over70s;
	}
	public int getFloatPp() {
		return floatPp;
	}
	public void setFloatPp(int floatPp) {
		this.floatPp = floatPp;
	}
	public int getIncome() {
		return income;
	}
	public void setIncome(int income) {
		this.income = income;
	}
	public int getDentalClinic() {
		return dentalClinic;
	}
	public void setDentalClinic(int dentalClinic) {
		this.dentalClinic = dentalClinic;
	}
	public int getSubway() {
		return subway;
	}
	public void setSubway(int subway) {
		this.subway = subway;
	}
	
	
}
