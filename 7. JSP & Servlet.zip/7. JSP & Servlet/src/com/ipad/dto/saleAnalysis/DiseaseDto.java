package com.ipad.dto.saleAnalysis;

public class DiseaseDto {
	private String diseaseCode;
	private int total_number, male, female, male_0, male_10, male_20, male_30, male_40, male_50, male_60, male_70, male_80, female_0, female_10, female_20, female_30, female_40, female_50, female_60, female_70, female_80;
	public String getDiseaseCode() {
		return diseaseCode;
	}
	public void setDiseaseCode(String diseaseCode) {
		this.diseaseCode = diseaseCode;
	}
	public int getTotal_number() {
		return total_number;
	}
	public void setTotal_number(int total_number) {
		this.total_number = total_number;
	}
	public int getMale() {
		return male;
	}
	public void setMale(int male) {
		this.male = male;
	}
	public int getFemale() {
		return female;
	}
	public void setFemale(int female) {
		this.female = female;
	}
	public int getMale_0() {
		return male_0;
	}
	public void setMale_0(int male_0) {
		this.male_0 = male_0;
	}
	public int getMale_10() {
		return male_10;
	}
	public void setMale_10(int male_10) {
		this.male_10 = male_10;
	}
	public int getMale_20() {
		return male_20;
	}
	public void setMale_20(int male_20) {
		this.male_20 = male_20;
	}
	public int getMale_30() {
		return male_30;
	}
	public void setMale_30(int male_30) {
		this.male_30 = male_30;
	}
	public int getMale_40() {
		return male_40;
	}
	public void setMale_40(int male_40) {
		this.male_40 = male_40;
	}
	public int getMale_50() {
		return male_50;
	}
	public void setMale_50(int male_50) {
		this.male_50 = male_50;
	}
	public int getMale_60() {
		return male_60;
	}
	public void setMale_60(int male_60) {
		this.male_60 = male_60;
	}
	public int getMale_70() {
		return male_70;
	}
	public void setMale_70(int male_70) {
		this.male_70 = male_70;
	}
	public int getMale_80() {
		return male_80;
	}
	public void setMale_80(int male_80) {
		this.male_80 = male_80;
	}
	public int getFemale_0() {
		return female_0;
	}
	public void setFemale_0(int female_0) {
		this.female_0 = female_0;
	}
	public int getFemale_10() {
		return female_10;
	}
	public void setFemale_10(int female_10) {
		this.female_10 = female_10;
	}
	public int getFemale_20() {
		return female_20;
	}
	public void setFemale_20(int female_20) {
		this.female_20 = female_20;
	}
	public int getFemale_30() {
		return female_30;
	}
	public void setFemale_30(int female_30) {
		this.female_30 = female_30;
	}
	public int getFemale_40() {
		return female_40;
	}
	public void setFemale_40(int female_40) {
		this.female_40 = female_40;
	}
	public int getFemale_50() {
		return female_50;
	}
	public void setFemale_50(int female_50) {
		this.female_50 = female_50;
	}
	public int getFemale_60() {
		return female_60;
	}
	public void setFemale_60(int female_60) {
		this.female_60 = female_60;
	}
	public int getFemale_70() {
		return female_70;
	}
	public void setFemale_70(int female_70) {
		this.female_70 = female_70;
	}
	public int getFemale_80() {
		return female_80;
	}
	public void setFemale_80(int female_80) {
		this.female_80 = female_80;
	}
}
